package Model;

public class LoginResponse {
    String message;
    User user;

    public LoginResponse() {
        user = null;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
