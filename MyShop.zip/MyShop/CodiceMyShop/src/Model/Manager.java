package Model;

public class Manager extends User{
    private String storeCity;

    public String getStoreCity() {
        return storeCity;
    }

    public void setStoreCity(String storeCity) {
        this.storeCity = storeCity;
    }
}
