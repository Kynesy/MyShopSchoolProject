package Model;

public class ItemVendor extends Vendor{
//lista prodotti

    public ItemVendor() {
    }

}
