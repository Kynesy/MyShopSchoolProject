package Model;

public interface ItemInterface {
    double getPrice();
    int getID();
    ItemVendor getItemVendor();
    String getName();
}
