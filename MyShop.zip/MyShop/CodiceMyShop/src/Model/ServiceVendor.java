package Model;

public class ServiceVendor extends Vendor{
//fornitore di servizi
    public ServiceVendor() {
    }

}
