package Model;

public class Administrator extends User{

    public Administrator() {

    }
}
