package Model;

public class Vendor {
    private String name;
    private String website;
    private String city;
    private String nation;

    public Vendor() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    @Override
    public String toString() {
        return "["+ getName() +" - "+ getWebsite() +" - "+ getCity() +" - "+ getNation() +"]";
    }
}
