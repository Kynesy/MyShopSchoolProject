package Test;

import View.DefaultFrame;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class TestMyShop {
    public static void main(String[] args) throws IOException {

        JFrame myShop = new DefaultFrame("MyShop");
    }
}
