package View;

import javax.swing.*;

public interface IStandardFrame {
    JPanel getMainPanel();
    void setMainPanel(JPanel jPanel);
}
